class Address():
    def __init__(self, street, number, city, zip, country):
        self.street = street
        self.number = number
        self.city = city
        self.zip = zip
        self.country = country
