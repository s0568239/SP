class Booking():
    def __init__(self, booking_id, customer_id, car, begin, end):
        self.booking_id = booking_id
        self.customer_id = customer_id
        self.begin = begin
        self.end = end