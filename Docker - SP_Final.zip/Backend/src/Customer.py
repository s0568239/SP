from Address import Address

class Customer():
    def __init__(self, customer_id, name, street, number, city, zip, country, age):
        self.customer_id = customer_id
        self.name = name
        self.street = street
        self.number = number
        self.city = city
        self.zip = zip
        self.country = country
        self.age = age
