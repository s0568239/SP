class Car:
    car_id = "car id"
    brand = "brand"
    name = "name"
    seats = "seats"
    color = "color"
    price = "price"
    status = "status"
    